+++
date = "2015-03-17T15:36:56Z"
title = "Getting help"
[menu.main]
  weight = 90
  pre = "<i class='fa fa-question'></i>"
+++

## Getting help

Often, the quickest way to get support for general questions is through
the
[mongodb-user google group](http://groups.google.com/group/mongodb-user)
or through
[Stack Overflow](https://stackoverflow.com/questions/tagged/mongodb%20c%2b%2b).

Please also refer to MongoDB's
[support channels](<http://www.mongodb.org/about/support) documentation.

